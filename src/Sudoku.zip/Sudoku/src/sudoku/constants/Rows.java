package sudoku.constants;

public enum Rows {
    TOP,
    MIDDLE,
    BOTTOM,
}
